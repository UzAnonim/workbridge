from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .forms import (EmployerRegistrationForm, JobSeekerRegistrationForm,
                    EmployerProfileUpdateForm, JobSeekerProfileUpdateForm,
                    LanguageSkillForm, EducationForm, WorkExperienceForm, LoginForm)
from .models import CustomUser, EmployerProfile, JobSeekerProfile, LanguageSkill, Education, WorkExperience


def register_choice(request):
    return render(request, 'accounts/register_choice.html')


def register_employer(request):
    if request.method == 'POST':
        form = EmployerRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Muvaffaqiyatli ro'yxatdan o'tdingiz!")
            return redirect('employer_dashboard')
    else:
        form = EmployerRegistrationForm()
    return render(request, 'accounts/register_employer.html', {'form': form})


def register_jobseeker(request):
    if request.method == 'POST':
        form = JobSeekerRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Muvaffaqiyatli ro'yxatdan o'tdingiz!")
            return redirect('jobseeker_dashboard')
    else:
        form = JobSeekerRegistrationForm()
    return render(request, 'accounts/register_jobseeker.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            try:
                user_obj = CustomUser.objects.get(email=email)
                user = authenticate(request, username=user_obj.username, password=password)
                if user:
                    login(request, user)
                    messages.success(request, "Xush kelibsiz!")
                    next_url = request.GET.get('next', 'home')
                    return redirect(next_url)
                else:
                    messages.error(request, "Email yoki parol noto'g'ri!")
            except CustomUser.DoesNotExist:
                messages.error(request, "Bu email bilan foydalanuvchi topilmadi!")
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('home')


@login_required
def employer_dashboard(request):
    if not request.user.is_employer:
        return redirect('home')
    try:
        profile = request.user.employer_profile
    except EmployerProfile.DoesNotExist:
        return redirect('home')
    return render(request, 'accounts/employer_dashboard.html', {'profile': profile})


@login_required
def jobseeker_dashboard(request):
    if not request.user.is_jobseeker:
        return redirect('home')
    try:
        profile = request.user.jobseeker_profile
    except JobSeekerProfile.DoesNotExist:
        return redirect('home')
    languages = profile.languages.all()
    education = profile.education.all()
    experiences = profile.experiences.all()
    return render(request, 'accounts/jobseeker_dashboard.html', {
        'profile': profile,
        'languages': languages,
        'education': education,
        'experiences': experiences,
    })


@login_required
def update_employer_profile(request):
    profile = get_object_or_404(EmployerProfile, user=request.user)
    if request.method == 'POST':
        form = EmployerProfileUpdateForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profil yangilandi!")
            return redirect('employer_dashboard')
    else:
        form = EmployerProfileUpdateForm(instance=profile)
    return render(request, 'accounts/update_employer_profile.html', {'form': form})


@login_required
def update_jobseeker_profile(request):
    profile = get_object_or_404(JobSeekerProfile, user=request.user)
    if request.method == 'POST':
        form = JobSeekerProfileUpdateForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profil yangilandi!")
            return redirect('jobseeker_dashboard')
    else:
        form = JobSeekerProfileUpdateForm(instance=profile)
    return render(request, 'accounts/update_jobseeker_profile.html', {'form': form})


@login_required
def add_language(request):
    if not request.user.is_jobseeker:
        return redirect('home')
    profile = get_object_or_404(JobSeekerProfile, user=request.user)
    if request.method == 'POST':
        form = LanguageSkillForm(request.POST, request.FILES)
        if form.is_valid():
            lang = form.save(commit=False)
            lang.jobseeker = profile
            lang.save()
            messages.success(request, "Til qo'shildi!")
            return redirect('jobseeker_dashboard')
    else:
        form = LanguageSkillForm()
    return render(request, 'accounts/add_language.html', {'form': form})


@login_required
def add_education(request):
    if not request.user.is_jobseeker:
        return redirect('home')
    profile = get_object_or_404(JobSeekerProfile, user=request.user)
    if request.method == 'POST':
        form = EducationForm(request.POST, request.FILES)
        if form.is_valid():
            edu = form.save(commit=False)
            edu.jobseeker = profile
            edu.save()
            messages.success(request, "Ta'lim qo'shildi!")
            return redirect('jobseeker_dashboard')
    else:
        form = EducationForm()
    return render(request, 'accounts/add_education.html', {'form': form})


@login_required
def add_experience(request):
    if not request.user.is_jobseeker:
        return redirect('home')
    profile = get_object_or_404(JobSeekerProfile, user=request.user)
    if request.method == 'POST':
        form = WorkExperienceForm(request.POST)
        if form.is_valid():
            exp = form.save(commit=False)
            exp.jobseeker = profile
            exp.save()
            messages.success(request, "Tajriba qo'shildi!")
            return redirect('jobseeker_dashboard')
    else:
        form = WorkExperienceForm()
    return render(request, 'accounts/add_experience.html', {'form': form})


def employer_public_profile(request, pk):
    profile = get_object_or_404(EmployerProfile, pk=pk)
    return render(request, 'accounts/employer_public_profile.html', {'profile': profile})


def jobseeker_public_profile(request, pk):
    profile = get_object_or_404(JobSeekerProfile, pk=pk)
    languages = profile.languages.all()
    education = profile.education.all()
    experiences = profile.experiences.all()
    return render(request, 'accounts/jobseeker_public_profile.html', {
        'profile': profile,
        'languages': languages,
        'education': education,
        'experiences': experiences,
    })

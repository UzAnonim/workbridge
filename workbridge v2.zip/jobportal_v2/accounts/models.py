from django.contrib.auth.models import AbstractUser
from django.db import models

LANGUAGE_LEVELS = [
    ('A1', 'A1 - Boshlang\'ich'),
    ('A2', 'A2 - Asosiy'),
    ('B1', 'B1 - O\'rta'),
    ('B2', 'B2 - O\'rta yuqori'),
    ('C1', 'C1 - Ilg\'or'),
    ('C2', 'C2 - Mukammal'),
    ('native', 'Ona tili'),
]

COUNTRIES = [
    ('DE', 'Germaniya'),
    ('AT', 'Avstriya'),
    ('CH', 'Shveytsariya'),
    ('NL', 'Niderlandiya'),
    ('UZ', 'O\'zbekiston'),
    ('KZ', 'Qozog\'iston'),
    ('KG', 'Qirg\'iziston'),
    ('TJ', 'Tojikiston'),
    ('TR', 'Turkiya'),
    ('OTHER', 'Boshqa'),
]

class CustomUser(AbstractUser):
    USER_TYPE_CHOICES = [
        ('employer', 'Ish beruvchi'),
        ('jobseeker', 'Ish qidiruvchi'),
    ]
    user_type = models.CharField(max_length=20, choices=USER_TYPE_CHOICES, default='jobseeker')
    email = models.EmailField(unique=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return self.email

    @property
    def is_employer(self):
        return self.user_type == 'employer'

    @property
    def is_jobseeker(self):
        return self.user_type == 'jobseeker'


class EmployerProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='employer_profile')
    company_name = models.CharField(max_length=200, verbose_name="Kompaniya nomi")
    company_logo = models.ImageField(upload_to='employer_logos/', blank=True, null=True, verbose_name="Kompaniya logosi")
    country = models.CharField(max_length=10, choices=COUNTRIES, default='DE', verbose_name="Davlat")
    city = models.CharField(max_length=100, verbose_name="Shahar")
    address = models.CharField(max_length=300, blank=True, verbose_name="Manzil")
    website = models.URLField(blank=True, verbose_name="Veb-sayt")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Telefon")
    industry = models.CharField(max_length=200, verbose_name="Soha")
    company_size = models.CharField(max_length=50, blank=True, verbose_name="Xodimlar soni")
    description = models.TextField(blank=True, verbose_name="Kompaniya haqida")
    founded_year = models.IntegerField(blank=True, null=True, verbose_name="Tashkil etilgan yil")
    is_verified = models.BooleanField(default=False, verbose_name="Tasdiqlangan")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.company_name

    class Meta:
        verbose_name = "Ish beruvchi profili"
        verbose_name_plural = "Ish beruvchi profillari"


class JobSeekerProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='jobseeker_profile')
    photo = models.ImageField(upload_to='jobseeker_photos/', blank=True, null=True, verbose_name="Profil rasmi")
    first_name = models.CharField(max_length=100, verbose_name="Ism")
    last_name = models.CharField(max_length=100, verbose_name="Familiya")
    date_of_birth = models.DateField(blank=True, null=True, verbose_name="Tug'ilgan sana")
    country = models.CharField(max_length=10, choices=COUNTRIES, default='UZ', verbose_name="Davlat")
    city = models.CharField(max_length=100, verbose_name="Shahar")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Telefon")
    bio = models.TextField(blank=True, verbose_name="O'zim haqimda")
    desired_position = models.CharField(max_length=200, blank=True, verbose_name="Maqsadli lavozim")
    experience_years = models.IntegerField(default=0, verbose_name="Tajriba (yil)")
    cv = models.FileField(upload_to='cvs/', blank=True, null=True, verbose_name="CV/Rezyume")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    class Meta:
        verbose_name = "Ish qidiruvchi profili"
        verbose_name_plural = "Ish qidiruvchi profillari"


class LanguageSkill(models.Model):
    jobseeker = models.ForeignKey(JobSeekerProfile, on_delete=models.CASCADE, related_name='languages')
    language = models.CharField(max_length=50, verbose_name="Til")
    level = models.CharField(max_length=10, choices=LANGUAGE_LEVELS, verbose_name="Daraja")
    certificate = models.FileField(upload_to='certificates/', blank=True, null=True, verbose_name="Sertifikat")

    def __str__(self):
        return f"{self.language} - {self.level}"

    class Meta:
        verbose_name = "Til bilimi"
        verbose_name_plural = "Til bilimlari"


class Education(models.Model):
    jobseeker = models.ForeignKey(JobSeekerProfile, on_delete=models.CASCADE, related_name='education')
    institution = models.CharField(max_length=200, verbose_name="Ta'lim muassasasi")
    degree = models.CharField(max_length=200, verbose_name="Diplom/Daraja")
    field = models.CharField(max_length=200, verbose_name="Yo'nalish")
    start_year = models.IntegerField(verbose_name="Boshlagan yili")
    end_year = models.IntegerField(blank=True, null=True, verbose_name="Tugatgan yili")
    is_current = models.BooleanField(default=False, verbose_name="Hozir o'qiyapman")
    diploma_file = models.FileField(upload_to='diplomas/', blank=True, null=True, verbose_name="Diplom fayli")

    def __str__(self):
        return f"{self.institution} - {self.degree}"

    class Meta:
        verbose_name = "Ta'lim"
        verbose_name_plural = "Ta'lim ma'lumotlari"


class WorkExperience(models.Model):
    jobseeker = models.ForeignKey(JobSeekerProfile, on_delete=models.CASCADE, related_name='experiences')
    company = models.CharField(max_length=200, verbose_name="Kompaniya")
    position = models.CharField(max_length=200, verbose_name="Lavozim")
    country = models.CharField(max_length=10, choices=COUNTRIES, blank=True, verbose_name="Davlat")
    start_date = models.DateField(verbose_name="Boshlagan sana")
    end_date = models.DateField(blank=True, null=True, verbose_name="Tugatgan sana")
    is_current = models.BooleanField(default=False, verbose_name="Hozir ishlayapman")
    description = models.TextField(blank=True, verbose_name="Tavsif")

    def __str__(self):
        return f"{self.company} - {self.position}"

    class Meta:
        verbose_name = "Ish tajribasi"
        verbose_name_plural = "Ish tajribalari"
        ordering = ['-start_date']

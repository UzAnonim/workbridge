from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, EmployerProfile, JobSeekerProfile, LanguageSkill, Education, WorkExperience


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ['email', 'username', 'user_type', 'is_active', 'date_joined']
    list_filter = ['user_type', 'is_active']
    search_fields = ['email', 'username']
    fieldsets = UserAdmin.fieldsets + (
        ('Foydalanuvchi turi', {'fields': ('user_type',)}),
    )


class LanguageSkillInline(admin.TabularInline):
    model = LanguageSkill
    extra = 1


class EducationInline(admin.TabularInline):
    model = Education
    extra = 1


class WorkExperienceInline(admin.TabularInline):
    model = WorkExperience
    extra = 1


@admin.register(EmployerProfile)
class EmployerProfileAdmin(admin.ModelAdmin):
    list_display = ['company_name', 'country', 'city', 'industry', 'is_verified']
    list_filter = ['country', 'is_verified']
    search_fields = ['company_name', 'city']
    list_editable = ['is_verified']


@admin.register(JobSeekerProfile)
class JobSeekerProfileAdmin(admin.ModelAdmin):
    list_display = ['full_name', 'country', 'city', 'desired_position', 'experience_years']
    list_filter = ['country']
    search_fields = ['first_name', 'last_name', 'desired_position']
    inlines = [LanguageSkillInline, EducationInline, WorkExperienceInline]

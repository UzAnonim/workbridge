from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, EmployerProfile, JobSeekerProfile, LanguageSkill, Education, WorkExperience


class EmployerRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True, label="Email")
    company_name = forms.CharField(max_length=200, label="Kompaniya nomi")
    country = forms.ChoiceField(choices=EmployerProfile._meta.get_field('country').choices, label="Davlat")
    city = forms.CharField(max_length=100, label="Shahar")
    industry = forms.CharField(max_length=200, label="Soha")
    phone = forms.CharField(max_length=20, required=False, label="Telefon")

    class Meta:
        model = CustomUser
        fields = ['email', 'username', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.user_type = 'employer'
        if commit:
            user.save()
            EmployerProfile.objects.create(
                user=user,
                company_name=self.cleaned_data['company_name'],
                country=self.cleaned_data['country'],
                city=self.cleaned_data['city'],
                industry=self.cleaned_data['industry'],
                phone=self.cleaned_data.get('phone', ''),
            )
        return user


class JobSeekerRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True, label="Email")
    first_name = forms.CharField(max_length=100, label="Ism")
    last_name = forms.CharField(max_length=100, label="Familiya")
    country = forms.ChoiceField(choices=JobSeekerProfile._meta.get_field('country').choices, label="Davlat")
    city = forms.CharField(max_length=100, label="Shahar")
    phone = forms.CharField(max_length=20, required=False, label="Telefon")
    desired_position = forms.CharField(max_length=200, required=False, label="Maqsadli lavozim")
    photo = forms.ImageField(required=False, label="Profil rasmi")

    class Meta:
        model = CustomUser
        fields = ['email', 'username', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.user_type = 'jobseeker'
        if commit:
            user.save()
            profile = JobSeekerProfile.objects.create(
                user=user,
                first_name=self.cleaned_data['first_name'],
                last_name=self.cleaned_data['last_name'],
                country=self.cleaned_data['country'],
                city=self.cleaned_data['city'],
                phone=self.cleaned_data.get('phone', ''),
                desired_position=self.cleaned_data.get('desired_position', ''),
            )
            if self.cleaned_data.get('photo'):
                profile.photo = self.cleaned_data['photo']
                profile.save()
        return user


class EmployerProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = EmployerProfile
        fields = ['company_name', 'company_logo', 'country', 'city', 'address',
                  'website', 'phone', 'industry', 'company_size', 'description', 'founded_year']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }


class JobSeekerProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = JobSeekerProfile
        fields = ['photo', 'first_name', 'last_name', 'date_of_birth', 'country',
                  'city', 'phone', 'bio', 'desired_position', 'experience_years', 'cv']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 4}),
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }


class LanguageSkillForm(forms.ModelForm):
    class Meta:
        model = LanguageSkill
        fields = ['language', 'level', 'certificate']


class EducationForm(forms.ModelForm):
    class Meta:
        model = Education
        fields = ['institution', 'degree', 'field', 'start_year', 'end_year', 'is_current', 'diploma_file']


class WorkExperienceForm(forms.ModelForm):
    class Meta:
        model = WorkExperience
        fields = ['company', 'position', 'country', 'start_date', 'end_date', 'is_current', 'description']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 3}),
        }


class LoginForm(forms.Form):
    email = forms.EmailField(label="Email")
    password = forms.CharField(widget=forms.PasswordInput, label="Parol")

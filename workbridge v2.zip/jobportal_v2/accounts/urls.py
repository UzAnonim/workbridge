from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_choice, name='register_choice'),
    path('register/employer/', views.register_employer, name='register_employer'),
    path('register/jobseeker/', views.register_jobseeker, name='register_jobseeker'),
    path('dashboard/employer/', views.employer_dashboard, name='employer_dashboard'),
    path('dashboard/jobseeker/', views.jobseeker_dashboard, name='jobseeker_dashboard'),
    path('profile/employer/update/', views.update_employer_profile, name='update_employer_profile'),
    path('profile/jobseeker/update/', views.update_jobseeker_profile, name='update_jobseeker_profile'),
    path('profile/language/add/', views.add_language, name='add_language'),
    path('profile/education/add/', views.add_education, name='add_education'),
    path('profile/experience/add/', views.add_experience, name='add_experience'),
    path('employer/<int:pk>/', views.employer_public_profile, name='employer_public_profile'),
    path('jobseeker/<int:pk>/', views.jobseeker_public_profile, name='jobseeker_public_profile'),
]

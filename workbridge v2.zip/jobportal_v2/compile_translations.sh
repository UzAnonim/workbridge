#!/bin/bash
# PythonAnywhere da ishga tushirish skripti

echo "=== WorkBridge v2 - Ko'p tillilik ==="

cd ~/jobportal

# Tarjima fayllarini compile qilish
python3.10 -c "
import subprocess
import os
os.chdir('/home/UzAnonim/jobportal')

# .po fayllardan .mo fayllar yaratish
for lang in ['uz', 'de', 'en']:
    po_file = f'locale/{lang}/LC_MESSAGES/django.po'
    mo_file = f'locale/{lang}/LC_MESSAGES/django.mo'
    if os.path.exists(po_file):
        result = subprocess.run(['msgfmt', po_file, '-o', mo_file], capture_output=True)
        if result.returncode == 0:
            print(f'{lang}: OK')
        else:
            print(f'{lang}: {result.stderr.decode()}')
"

echo "Tarjimalar tayyor!"

from django.shortcuts import render
from accounts.models import EmployerProfile, JobSeekerProfile


def home(request):
    employers = EmployerProfile.objects.order_by('-created_at')
    jobseekers = JobSeekerProfile.objects.order_by('-created_at')
    return render(request, 'jobs/home.html', {
        'employers': employers,
        'jobseekers': jobseekers,
    })


def employers_list(request):
    employers = EmployerProfile.objects.order_by('-created_at')
    return render(request, 'jobs/employers_list.html', {'employers': employers})


def jobseekers_list(request):
    jobseekers = JobSeekerProfile.objects.order_by('-created_at')
    return render(request, 'jobs/jobseekers_list.html', {'jobseekers': jobseekers})

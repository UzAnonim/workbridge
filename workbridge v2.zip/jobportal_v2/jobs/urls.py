from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('employers/', views.employers_list, name='employers_list'),
    path('jobseekers/', views.jobseekers_list, name='jobseekers_list'),
]
